# 🎞️ MemoryCraft AI — Intelligent Event Memory Creator

Turn ordinary photos and videos into **cinematic stories** for life's most
important occasions. Upload memories, pick an event and a theme, click
**Generate** — MemoryCraft AI acts as your photographer, video editor,
designer and album maker, all in one.

## ✨ What it creates

| Deliverable | Description |
|---|---|
| 🎬 Cinematic film | Full-HD slideshow with Ken Burns pan & zoom, crossfades, themed opening/closing scenes, lower-third captions and synchronized music |
| 📖 PDF memory book | Print-ready album: cover, event info, timeline, photos with captions, family wishes, thank-you page |
| 🖼️ Photo collage | Themed mosaic poster for social covers |
| 🗓️ Interactive timeline | Plotly timeline of dated memories, exportable HTML |
| 🔗 QR share card | Themed poster guests can scan to open your video |

## 🎉 Supported occasions

Birthday · Wedding · Anniversary · Silver & Golden Jubilee · Graduation ·
Baby Shower · House Warming · Family Reunion · Travel · Festivals ·
Retirement · Farewell · Memorial Tribute · Custom — each with its own
design language, pacing, copy and music suggestions.

## 🧠 Automatic intelligence

- Sorts photos chronologically using EXIF capture dates
- Removes near-duplicate shots (perceptual hashing)
- Validates files and skips corrupt uploads gracefully
- Handles portrait/landscape without distortion (cinematic blurred-fill letterbox)
- Gentle auto-enhancement (CLAHE contrast, saturation lift, unsharp mask)
- Loops/trims and fades background music to match the film exactly

## 🚀 Installation

Requires **Python 3.10+** (tested on 3.12). FFmpeg is bundled via
`imageio-ffmpeg` — no separate install needed.

```bash
git clone <your-repo-url> memorycraft && cd memorycraft
python -m venv .venv
.venv\Scripts\activate          # Windows   (source .venv/bin/activate on macOS/Linux)
pip install -r requirements.txt
```

Optional — create demo photos with EXIF dates to try the app instantly:

```bash
python scripts/make_samples.py
```

## ▶️ Run

```bash
streamlit run app.py
```

Open http://localhost:8501, then follow the five-step wizard:
**Occasion → Memories → Words → Style → Generate.**

Tip: use the *Draft preview (480p)* quality first — it renders in a
fraction of the time — then switch to *Full quality (1080p)* for the
final export.

## 🏗️ Architecture

```
Memory_Craft/
├── app.py                          # Streamlit entry point (thin shell)
├── requirements.txt
├── scripts/
│   └── make_samples.py             # demo asset generator
├── assets/samples/                 # generated demo photos
├── data/                           # created at runtime
│   ├── memorycraft.db              # SQLite database
│   ├── uploads/project_<id>/       # user media
│   └── output/project_<id>/        # generated deliverables
└── memorycraft/
    ├── config.py                   # paths, render settings, font map
    ├── services.py                 # application layer (UI ↔ domain)
    ├── core/                       # framework-free domain
    │   ├── models.py               # Project / EventDetails / MediaItem / Output
    │   ├── events.py               # 15 event profiles (copy, pacing, music mood)
    │   ├── themes.py               # 10 themes (colour, type, motion, framing)
    │   └── database.py             # SQLite repository
    ├── processing/                 # multimedia engine
    │   ├── image_processor.py      # EXIF, dedupe, enhance, smart framing
    │   ├── title_cards.py          # Pillow-rendered title cards & lower thirds
    │   ├── video_generator.py      # MoviePy 2.x cinematic renderer
    │   ├── collage.py              # mosaic posters
    │   ├── pdf_builder.py          # ReportLab memory book
    │   ├── timeline.py             # Plotly interactive timeline
    │   └── qr_share.py             # QR share cards
    ├── ui/                         # Streamlit pages (presentation only)
    │   ├── dashboard_page.py
    │   ├── create_page.py          # 5-step wizard
    │   ├── library_page.py         # search / edit / delete / download
    │   └── styles.py               # global CSS
    └── utils/
        ├── files.py                # safe uploads, slugs, project folders
        └── fonts.py                # cross-platform font resolution
```

**Design principles**

- **Clean layering** — UI never touches SQL or MoviePy; it talks to
  `ProjectService`, which orchestrates a framework-free domain.
- **Theme as single source of truth** — one `Theme` object drives the
  film, PDF, collage, timeline and QR card, so every deliverable matches.
- **Registry pattern** — adding a new occasion or theme is a one-entry
  change in `events.py` / `themes.py`.
- **Fail-soft media pipeline** — one corrupt photo logs a warning and is
  skipped; it never kills a 300-photo render.

## ⚙️ Tuning

Edit `memorycraft/config.py`:

| Setting | Default | Meaning |
|---|---|---|
| `VIDEO_SIZE` / `VIDEO_FPS` | 1920×1080 / 30 | final render quality |
| `PHOTO_DURATION` | 4.0 s | seconds per slide (scaled by event pacing) |
| `CROSSFADE` | 0.9 s | transition overlap |
| `KEN_BURNS_ZOOM` | 1.12 | max pan & zoom factor |
| `MAX_UPLOAD_MB` | 200 | per-file upload limit |

## 🧰 Tech stack (100% free & open-source)

Python · Streamlit · MoviePy 2 · OpenCV · Pillow · NumPy · Plotly ·
ReportLab · qrcode · SQLite

## 📄 License

MIT — use it, fork it, celebrate with it.
